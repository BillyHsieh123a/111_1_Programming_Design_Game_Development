void playMenu();
void playBattle();
void playWin();
void playLose();
